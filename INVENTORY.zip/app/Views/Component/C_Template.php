<?= $this->include('Component/C_Header') ?>
<?= $this->include('Component/C_Side') ?>
<?= $this->include('Component/C_Top') ?>
<?= $this->renderSection('konten') ?>
<?= $this->include('Component/C_Footer') ?>