<?= $this->include('user/C_Header') ?>
<?= $this->include('user/C_Top') ?>
<?= $this->renderSection('konten') ?>
<?= $this->include('user/C_Footer') ?>